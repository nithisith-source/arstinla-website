# ไม้ต่อไม้ – บันทึกเทรด (เวอร์ชันขายจริง)

แอปบันทึกเทรดฟิวเจอร์ส: อ่านภาพหน้าจอจากแอปโบรก → จับคู่ไม้ → สถิติ/วินัยตามแผน
โครงสร้าง: **PWA** (เว็บแอป ใช้ออฟไลน์ได้) + **Cloudflare Worker** (อ่านภาพ + ตรวจการซื้อ) + **TWA** (ห่อเป็นแอป Android ขึ้น Play Store)

```
web/      เว็บแอป (อัปโหลดทั้งโฟลเดอร์ขึ้นโฮสต์)
worker/   API ฝั่งเซิร์ฟเวอร์ (เก็บ API key ไว้ที่นี่ ไม่อยู่ในแอป)
twa/      ไฟล์ช่วยตั้งค่าแอป Android
```

## โมเดลรายได้
- **ฟรี:** ทุกฟีเจอร์ + อ่านภาพหน้าจอ 5 ครั้ง/เดือน (กรอกเอง/แก้ตารางได้ไม่จำกัด)
- **Pro (subscription รายเดือนผ่าน Google Play):** อ่านภาพได้ 300 ครั้ง/เดือน
- เหตุผล: การอ่านภาพเป็นส่วนเดียวที่มีต้นทุนจริง (ค่า Claude API) จึงเก็บเงินตรงนั้น

## ช่องที่ต้องกรอกก่อนเปิดตัว (ค้นคำว่า `YOUR` และ `[`)
| ไฟล์ | ค่า |
|---|---|
| web/config.js | API_BASE, PLAY_STORE_URL, SUPPORT_EMAIL |
| worker/wrangler.toml | ALLOWED_ORIGINS, PACKAGE_NAME, KV id |
| web/.well-known/assetlinks.json | package name + SHA-256 จาก Play Console |
| web/privacy.html, web/terms.html | วันที่, ชื่อผู้พัฒนา, อีเมล, ที่อยู่ |
| twa/twa-manifest-additions.json | packageId (เช่น com.yourname.maitormai — เปลี่ยนภายหลังไม่ได้) |

## ขั้นตอน
### 1. บัญชีที่ต้องมี
- Cloudflare (ฟรี) — โฮสต์เว็บ + Worker
- Anthropic Console — สร้าง API key และตั้ง spending limit
- Google Play Console — บัญชีนักพัฒนา (ค่าสมัครครั้งเดียว)
- Google Cloud — สำหรับ service account ตรวจการซื้อ

### 2. Worker (API)
```bash
npm i -g wrangler
cd worker
wrangler login
wrangler kv namespace create QUOTA          # นำ id ไปใส่ wrangler.toml
wrangler secret put ANTHROPIC_API_KEY
wrangler secret put ENTITLEMENT_SECRET      # สุ่มยาว 32+ ตัวอักษร: openssl rand -hex 32
wrangler secret put GOOGLE_SA_JSON          # วางเนื้อหาไฟล์ JSON ของ service account (ทำในขั้นที่ 5)
wrangler deploy                             # ได้ URL -> ใส่ API_BASE ใน web/config.js
```

### 3. เว็บแอป
อัปโหลดโฟลเดอร์ `web/` ขึ้น Cloudflare Pages (หรือโฮสต์ที่รองรับ HTTPS) ใช้โดเมนหรือ subdomain ของแบรนด์นี้ แยกจากเว็บสำนักงาน
ตรวจว่าเปิด `https://โดเมน/.well-known/assetlinks.json` ได้

### 4. แอป Android (TWA)
```bash
npm i -g @bubblewrap/cli
bubblewrap init --manifest https://โดเมน/manifest.webmanifest
# รวมค่าจาก twa/twa-manifest-additions.json เข้า twa-manifest.json แล้ว
bubblewrap update
bubblewrap build        # ได้ app-release-bundle.aab
```
เก็บไฟล์ keystore และรหัสผ่านให้ดี ถ้าหายจะอัปเดตแอปไม่ได้

### 5. Play Console
1. สร้างแอป → อัปโหลด .aab ใน Internal testing
2. Setup → App signing → คัดลอก SHA-256 ไปใส่ assetlinks.json แล้วอัปโหลดเว็บใหม่
3. Monetize → Subscriptions → สร้าง product id `pro_monthly` (ต้องตรงกับ config.js) ตั้งราคา
4. Google Cloud: สร้าง service account, เปิด Google Play Android Developer API, สร้าง key (JSON)
   แล้วใน Play Console → Users and permissions → เชิญอีเมล service account ให้สิทธิ์ดูข้อมูลการเงินและจัดการคำสั่งซื้อ
5. กรอก Data safety (ข้อมูลเก็บในเครื่อง, ภาพส่งไปประมวลผลแต่ไม่เก็บ), Content rating, กลุ่มเป้าหมาย 18+
6. ใส่ลิงก์ privacy.html ในหน้าร้าน
7. บัญชีนักพัฒนาส่วนบุคคลใหม่ต้องผ่าน closed testing ตามจำนวนผู้ทดสอบและระยะเวลาที่ Google กำหนดก่อนเปิด production — ตรวจเงื่อนไขล่าสุดใน Play Console

### 6. ทดสอบก่อนเปิดจริง
- เพิ่มอีเมลตัวเองเป็น License tester → ซื้อ Pro ใน internal testing (ไม่เสียเงินจริง)
- ทดสอบ: ซื้อ → อ่านภาพ → ลบแอป/ติดตั้งใหม่ → กู้คืนการซื้อ
- ทดสอบอ่านภาพจากหลายวัน หลายความยาว ถ้า Haiku อ่านพลาดบ่อย เปลี่ยน MODEL เป็น claude-sonnet-5-5 (แพงขึ้น)

## ข้อควรรู้
- ข้อมูลการเทรดอยู่ในเครื่องผู้ใช้เท่านั้น → ผู้ใช้ต้องกด "สำรองข้อมูล" เอง (มีปุ่มในตั้งค่า)
- ฟีเจอร์ซื้อ Pro ทำงานเฉพาะในแอปที่ติดตั้งจาก Play Store; บนเว็บเบราว์เซอร์จะใช้ได้แค่แบบฟรี
- โค้ดส่วนชำระเงินและตรวจการซื้อเขียนตามเอกสาร Google แต่ยังไม่ได้ทดสอบกับบัญชีจริง ต้องผ่านขั้นที่ 6 ก่อนเปิดขาย
