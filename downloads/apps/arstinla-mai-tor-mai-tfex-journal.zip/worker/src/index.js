// ไม้ต่อไม้ API — Cloudflare Worker
// POST /api/read    อ่านภาพหน้าจอรายการคำสั่ง -> fills (เรียก Claude API, เก็บ API key ฝั่ง server)
// POST /api/verify  ยืนยัน subscription จาก Google Play -> entitlement token (HMAC)
//
// Secrets (wrangler secret put ...): ANTHROPIC_API_KEY, ENTITLEMENT_SECRET, GOOGLE_SA_JSON
// Vars (wrangler.toml): ALLOWED_ORIGINS, PACKAGE_NAME, MODEL, FREE_READS, PRO_READS, IP_READS
// KV binding: QUOTA

const PROMPT = `The images are consecutive screenshots (possibly overlapping slices) of a Thai broker app order list for TFEX futures.
Each order card shows: symbol (e.g. S50Z26), a Long/Short badge, เวลา (DD/MM/YYYY HH:MM:SS), Volume, จับคู่สำเร็จ (matched volume), ราคา (order price), ราคาจับคู่ (matched price), สถานะ (Matched / Cancelled / Expired / Pending), ID คำสั่งซื้อขาย (order id).
Extract ONLY orders whose matched volume (จับคู่สำเร็จ) is greater than 0. Use the matched volume as qty and the matched price (ราคาจับคู่), NOT the order price. Overlapping slices may show the same order twice: list each order id once.
If the images are not a broker order list, reply {"fills":[],"skipped":0,"unreadable":true}.
Reply with only JSON, no other text: {"fills":[{"date":"YYYY-MM-DD","time":"HH:MM:SS","symbol":"S50Z26","side":"Long","qty":2,"price":1049.10,"orderId":"56039537"}],"skipped":<number of orders not matched>}`;

const MAX_IMAGES = 8;
const MAX_B64_BYTES = 6 * 1024 * 1024;

export default {
  async fetch(req, env) {
    const origin = req.headers.get('origin') || '';
    const allowed = (env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean);
    const cors = {
      'access-control-allow-origin': allowed.includes(origin) ? origin : (allowed[0] || ''),
      'access-control-allow-methods': 'POST, OPTIONS',
      'access-control-allow-headers': 'content-type',
      'vary': 'origin',
    };
    if (req.method === 'OPTIONS') return new Response(null, { headers: cors });
    const json = (obj, status = 200) => new Response(JSON.stringify(obj), { status, headers: { ...cors, 'content-type': 'application/json' } });
    if (req.method !== 'POST') return json({ error: 'not found' }, 404);
    if (allowed.length && !allowed.includes(origin)) return json({ error: 'forbidden origin' }, 403);

    const url = new URL(req.url);
    let body;
    try { body = await req.json(); } catch { return json({ error: 'bad json', code: 'bad_request' }, 400); }

    try {
      if (url.pathname === '/api/read') return json(await handleRead(body, req, env));
      if (url.pathname === '/api/verify') return json(await handleVerify(body, env));
      return json({ error: 'not found' }, 404);
    } catch (e) {
      return json({ error: e.message || 'error', code: e.code || 'error' }, e.status || 500);
    }
  },
};

function fail(status, code, message) { return Object.assign(new Error(message || code), { status, code }); }
const month = () => new Date().toISOString().slice(0, 7);

// ---------- /api/read ----------
async function handleRead(body, req, env) {
  const deviceId = String(body.deviceId || '').slice(0, 64);
  if (!/^[A-Za-z0-9._-]{8,64}$/.test(deviceId)) throw fail(400, 'bad_request', 'deviceId');
  const images = Array.isArray(body.images) ? body.images.slice(0, MAX_IMAGES) : [];
  if (!images.length) throw fail(400, 'bad_request', 'no images');
  let total = 0;
  for (const im of images) {
    if (!im || (im.media_type !== 'image/jpeg' && im.media_type !== 'image/png') || typeof im.data !== 'string') throw fail(400, 'bad_request', 'image');
    total += im.data.length;
  }
  if (total > MAX_B64_BYTES) throw fail(413, 'too_large', 'images too large');

  // quota: Pro by entitlement, else per device; plus a per-IP ceiling against device-id rotation
  const ent = await readEntitlement(body.entitlement, env);
  const limit = ent ? Number(env.PRO_READS || 300) : Number(env.FREE_READS || 5);
  const who = ent ? 'p:' + ent.sub : 'd:' + deviceId;
  const qKey = `q:${who}:${month()}`;
  const used = Number(await env.QUOTA.get(qKey) || 0);
  if (used >= limit) throw fail(429, 'quota', 'monthly quota reached');
  if (!ent) {
    const ip = req.headers.get('cf-connecting-ip') || 'unknown';
    const ipKey = `ip:${ip}:${month()}`;
    const ipUsed = Number(await env.QUOTA.get(ipKey) || 0);
    if (ipUsed >= Number(env.IP_READS || 30)) throw fail(429, 'quota', 'ip quota reached');
    await env.QUOTA.put(ipKey, String(ipUsed + 1), { expirationTtl: 40 * 86400 });
  }

  const content = images.map(im => ({ type: 'image', source: { type: 'base64', media_type: im.media_type, data: im.data } }));
  content.push({ type: 'text', text: PROMPT });
  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-api-key': env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({ model: env.MODEL, max_tokens: 4000, messages: [{ role: 'user', content }] }),
  });
  if (!r.ok) throw fail(502, 'upstream', 'model error ' + r.status);
  const data = await r.json();
  const text = (data.content || []).filter(c => c.type === 'text').map(c => c.text).join('');
  let parsed;
  try {
    const m = text.match(/\{[\s\S]*\}/);
    parsed = JSON.parse(m ? m[0] : text);
  } catch { throw fail(502, 'unreadable', 'could not parse'); }
  if (parsed.unreadable) throw fail(422, 'unreadable', 'not an order list');

  const fills = (Array.isArray(parsed.fills) ? parsed.fills : []).map(f => ({
    date: String(f.date || '').slice(0, 10), time: String(f.time || '').slice(0, 8), symbol: String(f.symbol || '').slice(0, 16),
    side: f.side === 'Short' ? 'Short' : 'Long', qty: Math.max(0, Math.round(Number(f.qty) || 0)), price: Number(f.price) || 0,
    orderId: String(f.orderId || '').slice(0, 32),
  })).filter(f => f.qty > 0 && f.price > 0);

  await env.QUOTA.put(qKey, String(used + 1), { expirationTtl: 40 * 86400 });
  return { fills, skipped: Number(parsed.skipped) || 0, remaining: Math.max(0, limit - used - 1) };
}

// ---------- entitlement token: base64url(payload).base64url(hmac) ----------
const b64u = buf => btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const b64uStr = s => b64u(new TextEncoder().encode(s));
const fromB64u = s => atob(s.replace(/-/g, '+').replace(/_/g, '/'));
async function hmacKey(env) {
  return crypto.subtle.importKey('raw', new TextEncoder().encode(env.ENTITLEMENT_SECRET), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign', 'verify']);
}
async function signEntitlement(payload, env) {
  const p = b64uStr(JSON.stringify(payload));
  const sig = await crypto.subtle.sign('HMAC', await hmacKey(env), new TextEncoder().encode(p));
  return p + '.' + b64u(sig);
}
async function readEntitlement(token, env) {
  if (typeof token !== 'string' || !token.includes('.')) return null;
  const [p, s] = token.split('.');
  try {
    const sig = Uint8Array.from(fromB64u(s), c => c.charCodeAt(0));
    const ok = await crypto.subtle.verify('HMAC', await hmacKey(env), sig, new TextEncoder().encode(p));
    if (!ok) return null;
    const payload = JSON.parse(fromB64u(p));
    return payload.exp * 1000 > Date.now() ? payload : null;
  } catch { return null; }
}

// ---------- /api/verify (Google Play subscription) ----------
async function handleVerify(body, env) {
  const token = String(body.purchaseToken || '');
  const sku = String(body.sku || '');
  if (!token || !sku) throw fail(400, 'bad_request', 'purchaseToken/sku');
  const access = await googleAccessToken(env);
  const base = `https://androidpublisher.googleapis.com/androidpublisher/v3/applications/${env.PACKAGE_NAME}/purchases`;
  const r = await fetch(`${base}/subscriptionsv2/tokens/${encodeURIComponent(token)}`, { headers: { authorization: 'Bearer ' + access } });
  if (!r.ok) throw fail(402, 'not_verified', 'play lookup ' + r.status);
  const sub = await r.json();
  const active = ['SUBSCRIPTION_STATE_ACTIVE', 'SUBSCRIPTION_STATE_IN_GRACE_PERIOD'].includes(sub.subscriptionState);
  const line = (sub.lineItems || []).find(l => l.productId === sku);
  if (!active || !line) throw fail(402, 'not_active', 'subscription not active');

  if (sub.acknowledgementState === 'ACKNOWLEDGEMENT_STATE_PENDING') {
    await fetch(`${base}/subscriptions/${encodeURIComponent(sku)}/tokens/${encodeURIComponent(token)}:acknowledge`, {
      method: 'POST', headers: { authorization: 'Bearer ' + access, 'content-type': 'application/json' }, body: '{}',
    });
  }
  const exp = Math.floor(new Date(line.expiryTime).getTime() / 1000);
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(sub.linkedPurchaseToken || token));
  const payload = { sub: b64u(digest).slice(0, 22), exp };
  return { entitlement: { token: await signEntitlement(payload, env), exp } };
}

async function googleAccessToken(env) {
  const sa = JSON.parse(env.GOOGLE_SA_JSON);
  const now = Math.floor(Date.now() / 1000);
  const head = b64uStr(JSON.stringify({ alg: 'RS256', typ: 'JWT' }));
  const claim = b64uStr(JSON.stringify({
    iss: sa.client_email, scope: 'https://www.googleapis.com/auth/androidpublisher',
    aud: 'https://oauth2.googleapis.com/token', iat: now, exp: now + 3600,
  }));
  const pem = sa.private_key.replace(/-----[^-]+-----/g, '').replace(/\s+/g, '');
  const key = await crypto.subtle.importKey('pkcs8', Uint8Array.from(atob(pem), c => c.charCodeAt(0)),
    { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['sign']);
  const sig = await crypto.subtle.sign('RSASSA-PKCS1-v1_5', key, new TextEncoder().encode(head + '.' + claim));
  const r = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: 'grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer&assertion=' + head + '.' + claim + '.' + b64u(sig),
  });
  if (!r.ok) throw fail(500, 'google_auth', 'google auth ' + r.status);
  return (await r.json()).access_token;
}
