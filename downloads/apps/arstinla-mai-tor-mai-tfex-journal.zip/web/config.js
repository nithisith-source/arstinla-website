// ===== ตั้งค่าก่อน deploy =====
window.APP_CONFIG = {
  APP_NAME: 'ไม้ต่อไม้',
  API_BASE: 'https://YOUR-WORKER.YOUR-ACCOUNT.workers.dev', // URL ของ Cloudflare Worker (ไม่มี / ท้าย)
  PRO_SKU: 'pro_monthly',                         // Product ID ของ subscription ใน Play Console
  FREE_READS_PER_MONTH: 5,                        // ต้องตรงกับ FREE_READS ใน worker (ใช้แสดงผลเท่านั้น)
  PLAY_STORE_URL: 'https://play.google.com/store/apps/details?id=YOUR.PACKAGE.ID',
  SUPPORT_EMAIL: 'YOUR-SUPPORT-EMAIL'
};
